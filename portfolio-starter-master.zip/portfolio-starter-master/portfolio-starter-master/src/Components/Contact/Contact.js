import React from "react";
import "./Contact.css";
import emailjs from '@emailjs/browser';
import { useRef } from "react";
import { useState } from "react";
import { useContext } from "react";
import { themeContext } from "../../Context";

const Contact = () => {
  const theme = useContext(themeContext);
  const darkMode = theme.state.darkMode;
    const form = useRef();
    const [Done , setDone] = useState(false)

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs.sendForm('service_epux7th', 'template_z0hwu0i', form.current, '5A5u412OEoAo6sPvn')
      .then((result) => {
          console.log(result.text);
          setDone(true)
      }, (error) => {
          console.log(error.text);
      });
  };
  return (
    <div className="contact" id="Contact">
      <div className="s-left c-left">
        <span style={{color: darkMode? 'white': ''}}>Get in Touch</span>
        <span>Contact me</span>
        <div className="blur s-blur1" style={{ background: "#ABF1FF94" }}></div>
      </div>
      <div className="c-right">
        <form ref={form} onSubmit={sendEmail}>
          <input
            type="text"
            placeholder="Name"
            name="user_name"
            className="user"
          />
          <input
            type="email"
            placeholder="Email"
            required
            name="user_email"
            className="user"
          />
          <textarea
            name="message"
            className="user"
            placeholder="Message"
          ></textarea>
          <input type="submit" value="Send" className="button" />
          <span>{Done && "Thanks for contacting me." }</span>
          <div
            className="
          blur c-blur1"
            style={{ background: "var(--purple)" }}
          ></div>
        </form>
      </div>
    </div>
  );
};

export default Contact;
