import React from "react";
import "./Service.css";
import "../Cards/Cards.css";
import HeartEmoji from "../../img/heartemoji.png";
import Glasses from "../../img/glasses.png";
import Humble from "../../img/humble.png";
import Cards from "../Cards/Cards";
import Resume from "./Muneeb's Resume.pdf";
import { themeContext } from "../../Context";
import { useContext } from "react";
import { motion } from "framer-motion";

function Service() {
  const transition = { duration: 2, typr: "spring" };
  const theme = useContext(themeContext);
  const darkMode = theme.state.darkMode;
  return (
    <div className="service" id="Services">
      <div className="s-left">
        <span style={{ color: darkMode ? "white" : "" }}>My Awesome</span>
        <span>services</span>
        <span>
          As a frontend web developer, I can offer a range of services related
          to HTML, CSS, JavaScript, and React.js. This includes building and
          designing websites, creating interactive web applications, and
          implementing responsive layouts. I am proficient in modern web
          development technologies and can deliver high-quality results in a
          timely manner.
        </span>
        <a href={Resume} download>
          <div className="button s-button">Download CV</div>
        </a>
        <div className="blur s-blur1" style={{ color: "#ABF1FF94" }}></div>
      </div>

      <div className="s-right">
        <motion.div
          initial={{ left: "25rem" }}
          whileInView={{ left: "14rem" }}
          transition={transition}
          className="cards"
          style={{ left: "14rem" }}
        >
          <Cards
            emoji={HeartEmoji}
            heading={"Design"}
            details={
              "Figma, Sketch, Adobe Photoshop, Adobe Illustrator, Adobe xd "
            }
          />
        </motion.div>

        <motion.div
          whileInView={{ left: "-4rem" }}
          initial={{ left: "-8rem" }}
          transition={transition}
          className="cards"
          style={{ top: "12rem", left: "-4rem" }}
        >
          <Cards
            emoji={Glasses}
            heading={"Developer"}
            details={
              "Html, Css, React, JavaScript, React, Node, Express and Mongo"
            }
          />
        </motion.div>
        <motion.div
          initial={{ left: "20rem" }}
          whileInView={{ left: "12.5rem" }}
          transition={transition}
          className="cards"
          style={{ top: "19rem", left: "12.5rem" }}
        >
          <Cards
            emoji={Humble}
            heading={"UI&UX"}
            details={"Modern UI&UX designs"}
          />
        </motion.div>
        <div
          className="blur s-blur2"
          style={{ background: "var(--purple)" }}
        ></div>
      </div>
    </div>
  );
}

export default Service;
