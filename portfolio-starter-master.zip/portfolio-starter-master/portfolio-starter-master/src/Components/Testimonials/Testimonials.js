import React from "react";
import "./Testimonials.css";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import profilePic1 from "../../img/profile1.jpg";
import profilePic2 from "../../img/profile2.jpg";
import profilePic3 from "../../img/profile3.jpg";
import profilePic4 from "../../img/profile4.jpg";
import { Pagination } from "swiper";
import "swiper/css/pagination";

const Testimonials = () => {
  const clients = [
    {
      img: profilePic1,
      name: "Elizaveta__nesmac",
      review:
        "I was amazed how fast and how responsible !!! He worked with me and did more than I asked !!! Great job !!!",
    },
    {
      img: profilePic2,
      name: "Sofia Volf",
      review:
        "Did an excellent job again and even helped when I needed help after he was done. Would definitely recommend and use again!",
    },
    {
      img: profilePic3,
      name: "Julia_vainberg",
      review:
        "Was very good at communicating, did so so much with such little time and was perfect at what he did. Also didn’t charge way too much which is hard to find. Would most definitely recommend and use again!",
    },
    {
      img: profilePic4,
      name: "Mr.khaylov",
      review:
        "He is like old wine he keeps on adding quality with time nice work and keep it up i will definetly seek your services each day of the month.",
    },
  ];
  return (
    <div className="t-wrapper">
      {/* {--Headings--} */}
      <div className="t-heading" id="Testimonals">
        <span>Clients always get </span>
        <span>Exceptional Work </span>
        <span>from me..</span>
        <div
          className="blur t-blur1"
          style={{ background: "var(--purple)" }}
        ></div>
        <div className="blur t-blur2" style={{ background: "skyblue" }}></div>
      </div>

      {/* Swiper  */}
      <Swiper
        modules={[Pagination]}
        pagination={{ clickable: true }}
        slidesPerView={1}
      >
        {clients.map((client, index) => {
          return (
            <SwiperSlide key={index}>
              <div className="testimonials">
                <img src={client.img} alt="" />
                <name>{client.name}</name>
                <span>{client.review}</span>
              </div>
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};

export default Testimonials;
